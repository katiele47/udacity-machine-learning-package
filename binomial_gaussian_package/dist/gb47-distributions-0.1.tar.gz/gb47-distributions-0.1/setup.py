from setuptools import setup

setup(name='gb47-distributions',
      version='0.1',
      description='Gaussian & Binomial distributions',
      packages=['gb47-distributions'],
      zip_safe=False)